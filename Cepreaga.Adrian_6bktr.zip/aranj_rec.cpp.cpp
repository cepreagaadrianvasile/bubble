//aranjamente recursiv
