//combinari recursiv
