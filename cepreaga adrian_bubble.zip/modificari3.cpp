#include<iostream>
#include<fstream>
using namespace std;
int n;
int v[100];
int main()
{fstream f;
f.open("input.dat", ios::in);
f>>n;
    for(int i=0;i<n;i++)
    {
        f>>v[i];
    }
    int gata=0;
    while(gata==0){
        gata=1;
    for(int i=0;i<=n-2;i++)
        if(v[i]<v[i+1]){
            swap(v[i+1],v[i]);
            gata=0;}



    }

for(int i=0;i<=n-1;i++)
    cout<<v[i]<<" ";
}
