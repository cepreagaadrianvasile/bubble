#include<iostream>
#include<fstream>
using namespace std;
int n;
int n2;
int V[100];
int main()
{
    fstream f;
    f.open("input.dat", ios::in);
    f>>n;
    for(int i=1;i<=n-1;i++)
    {
        f>>V[i];
    }
int gata=0;
    n2=n;
    while(n2){
        for(int i=1;i<=n;i++){
            if(i!=0){
                swap(V[i],V[i+1]);}
            if(i==n){
                swap(V[i+1],V[i]);}
            cout<<V[i]<<" ";}
        cout<<endl;
        n2--;}
}
